class MovieRecommender {
    constructor() {
        this.movies = [];
        this.init();
    }

    async init() {
        await this.loadMovies();
        this.setupEventListeners();
    }

    async loadMovies() {
        try {
            const data = await d3.csv('movies.csv');
            this.movies = data.map(movie => ({
                title: movie.title,
                genres: movie.genres ? movie.genres.split('|') : [],
                vote_average: parseFloat(movie.vote_average) || 0,
                vote_count: parseInt(movie.vote_count) || 0,
                popularity: parseFloat(movie.popularity) || 0,
                overview: movie.overview || '',
                director: movie.director || '',
                cast: movie.cast ? movie.cast.split('|').slice(0, 5) : []
            }));
            console.log(`Loaded ${this.movies.length} movies`);
        } catch (error) {
            console.error('Error loading movies:', error);
        }
    }

    setupEventListeners() {
        document.getElementById('searchBtn').addEventListener('click', () => {
            this.getRecommendations();
        });

        document.getElementById('movieInput').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.getRecommendations();
            }
        });
    }

    getRecommendations() {
        const input = document.getElementById('movieInput').value.trim();
        if (!input) {
            alert('Please enter a movie title');
            return;
        }

        const sourceMovie = this.findMovie(input);
        if (!sourceMovie) {
            alert('Movie not found in database. Please try another title.');
            return;
        }

        const recommendations = this.calculateSimilarity(sourceMovie);
        this.renderBarChart(recommendations, sourceMovie.title);
    }

    findMovie(title) {
        const lowerTitle = title.toLowerCase();
        return this.movies.find(movie => 
            movie.title.toLowerCase().includes(lowerTitle)
        );
    }

    calculateSimilarity(sourceMovie) {
        // Calculate min/max values for normalization
        const maxVoteCount = Math.max(...this.movies.map(m => m.vote_count));
        const maxPopularity = Math.max(...this.movies.map(m => m.popularity));
        
        const scores = this.movies.map(movie => {
            if (movie.title === sourceMovie.title) return null;

            let score = 0;
            
            // Genre similarity (50% weight)
            const genreSimilarity = this.calculateGenreSimilarity(
                sourceMovie.genres, 
                movie.genres
            );
            score += genreSimilarity * 0.5;

            // Enhanced Rating score (30% weight) - considers both rating and vote count
            const ratingScore = this.calculateEnhancedRatingScore(movie, maxVoteCount);
            score += ratingScore * 0.3;

            // Popularity score (20% weight)
            const popularityScore = movie.popularity / maxPopularity;
            score += popularityScore * 0.2;

            return {
                title: movie.title,
                score: Math.min(score * 100, 100), // Convert to percentage
                vote_average: movie.vote_average,
                vote_count: movie.vote_count,
                popularity: movie.popularity,
                genres: movie.genres
            };
        }).filter(item => item !== null);

        // Sort by score descending and take top 10
        return scores.sort((a, b) => b.score - a.score).slice(0, 10);
    }

    calculateEnhancedRatingScore(movie, maxVoteCount) {
        // Normalize vote average (0-10 scale to 0-1)
        const normalizedRating = movie.vote_average / 10;
        
        // Normalize vote count (more votes = more reliable rating)
        const voteConfidence = Math.min(movie.vote_count / maxVoteCount, 1);
        
        // Combine rating with vote confidence
        return normalizedRating * (0.7 + 0.3 * voteConfidence);
    }

    calculateGenreSimilarity(genres1, genres2) {
        if (!genres1.length || !genres2.length) return 0;
        
        const intersection = genres1.filter(genre => 
            genres2.includes(genre)
        ).length;
        
        const union = new Set([...genres1, ...genres2]).size;
        
        return union > 0 ? intersection / union : 0;
    }

    renderBarChart(recommendations, sourceMovieTitle) {
        // Clear previous chart
        d3.select('#chart').html('');

        // Set up dimensions
        const margin = { top: 50, right: 30, bottom: 50, left: 200 };
        const width = 800 - margin.left - margin.right;
        const height = 500 - margin.top - margin.bottom;

        // Create SVG
        const svg = d3.select('#chart')
            .append('svg')
            .attr('width', width + margin.left + margin.right)
            .attr('height', height + margin.top + margin.bottom)
            .append('g')
            .attr('transform', `translate(${margin.left},${margin.top})`);

        // Create scales
        const xScale = d3.scaleLinear()
            .domain([0, 100])
            .range([0, width]);

        const yScale = d3.scaleBand()
            .domain(recommendations.map(d => d.title))
            .range([0, height])
            .padding(0.1);

        // Create axes
        const xAxis = d3.axisBottom(xScale);
        const yAxis = d3.axisLeft(yScale);

        svg.append('g')
            .attr('class', 'x-axis')
            .attr('transform', `translate(0,${height})`)
            .call(xAxis);

        svg.append('g')
            .attr('class', 'y-axis')
            .call(yAxis);

        // Add axis labels
        svg.append('text')
            .attr('class', 'axis-label')
            .attr('transform', 'rotate(-90)')
            .attr('y', -160)
            .attr('x', -height / 2)
            .attr('dy', '1em')
            .style('text-anchor', 'middle')
            .text('Movies');

        svg.append('text')
            .attr('class', 'axis-label')
            .attr('transform', `translate(${width / 2}, ${height + 40})`)
            .style('text-anchor', 'middle')
            .text('Similarity Score (%)');

        // Add title
        svg.append('text')
            .attr('class', 'chart-title')
            .attr('x', width / 2)
            .attr('y', -20)
            .attr('text-anchor', 'middle')
            .style('font-size', '16px')
            .style('font-weight', 'bold')
            .text(`Top 10 Recommendations for "${sourceMovieTitle}"`);

        // Create bars
        const bars = svg.selectAll('.bar')
            .data(recommendations)
            .enter()
            .append('rect')
            .attr('class', 'bar')
            .attr('y', d => yScale(d.title))
            .attr('height', yScale.bandwidth())
            .attr('x', 0)
            .attr('width', 0) // Start from 0 for animation
            .transition()
            .duration(800)
            .attr('width', d => xScale(d.score));

        // Add score labels at the end of bars
        svg.selectAll('.score-label')
            .data(recommendations)
            .enter()
            .append('text')
            .attr('class', 'score-label')
            .attr('y', d => yScale(d.title) + yScale.bandwidth() / 2)
            .attr('x', d => xScale(d.score) + 5)
            .attr('dy', '0.35em')
            .style('font-size', '12px')
            .style('fill', '#333')
            .text(d => `${d.score.toFixed(1)}%`);

        // Add tooltip
        const tooltip = d3.select('body')
            .append('div')
            .attr('class', 'tooltip')
            .style('opacity', 0);

        bars.on('mouseover', function(event, d) {
            tooltip.transition()
                .duration(200)
                .style('opacity', .9);
            tooltip.html(`
                <strong>${d.title}</strong><br/>
                Score: ${d.score.toFixed(1)}%<br/>
                Rating: ${d.vote_average}/10 (${d.vote_count} votes)<br/>
                Popularity: ${d.popularity.toFixed(2)}<br/>
                Genres: ${d.genres.join(', ')}
            `)
                .style('left', (event.pageX + 10) + 'px')
                .style('top', (event.pageY - 28) + 'px');
            })
            .on('mouseout', function() {
                tooltip.transition()
                    .duration(500)
                    .style('opacity', 0);
            });
    }
}

// Initialize the recommender when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new MovieRecommender();
});